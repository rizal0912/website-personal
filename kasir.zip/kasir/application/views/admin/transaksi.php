<section class="content">
	<div class="container-fluid">
		<div class="block-header">
			<h2>TRANSAKSI</h2>
		</div>
		<div class="row clearfix">
			<div class="col-md-12">
				<div class="card">
					<div class="header">
						<div class="pull-left">
							<i class="fa fa-money"></i> Data transaksi
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="body">
						<table class="table table-bordered table-hovered table-transaksi" width="100%">
							<thead>
								<tr>
									<th>idtransaksi</th>
									<th>Total</th>
									<th>Bayar</th>
									<th>Kembalian</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>